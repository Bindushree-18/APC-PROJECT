#include"header.h"
void call_fun(char* argv[],d_list** list1,d_list** list2,d_list** tail1,d_list** tail2,int n_flag)
{
    d_list* r_head;
    if(argv[2][0]== '+')
    {
        printf("\naddition = ");
        if(argv[1][0]=='-' && argv[3][0]=='-')
        {
            r_head=addition(*tail1,*tail2);
            print_res(r_head,1);
            return;
        }
        if(n_flag)
        {
            if(argv[3][0]=='-')
            {
                r_head=subtraction(*tail1,*tail2);
                print_res(r_head,1);
                return;
            }
            if(argv[1][0]=='-')
            {
                r_head=subtraction(*tail1,*tail2);
                print_res(r_head,0);
                return;

            }
            else
            {
                r_head=addition(*tail1,*tail2);
                print_res(r_head,0);
                return ;
            }
        }
        else if(n_flag==0)
        {
            if(argv[3][0]=='-')
            {
                r_head=subtraction(*tail1,*tail2);
                print_res(r_head,0);
                return;
            }
            if(argv[1][0]=='-')
            {
                r_head=subtraction(*tail1,*tail2);
                print_res(r_head,1);
                return;

            }
            else
            {
                r_head=addition(*tail1,*tail2);
                print_res(r_head,0);
            }
        }

    }
    if(argv[2][0]== '-')
    {
        if(argv[1][0]=='-' && argv[3][0]=='-')
        {
            r_head=subtraction(*tail1,*tail2);
            printf("\nsubtraction = ");
            print_res(r_head,1);
            return;
        }
        else if(argv[3][0]=='-')
        {
            printf("\nsubtraction = ");
            r_head=addition(*tail1,*tail2);
            print_res(r_head,0);
            return;
        }
        else if(argv[1][0]=='-')
        {
            printf("\nsubtraction = ");
            r_head=addition(*tail1,*tail2);
            print_res(r_head,1);
            return;
        }
        else
        {
            r_head=subtraction(*tail1,*tail2);
            printf("\nsubtraction = ");
            print_res(r_head,n_flag);
            return;
        }
    }
    if(argv[2][0]=='x')
    {
        printf("multiplication = ");
        r_head=multi(*tail1,*tail2);
        if(argv[1][0]=='-' && argv[3][0]=='-')
        {
            print_res(r_head,0);
            return;
        }
        if(argv[1][0]=='-' || argv[3][0]=='-')
        {
            print_res(r_head,1);
            return;
        }
        print_res(r_head,0);
    }
    if(argv[2][0]=='/')
    {
        int count;
        count=division(*list1,*tail1,*list2,*tail2);
        printf("division = %d",count);
    }
}

void print_res(d_list* head,int n_flag)
{
    if(n_flag)
        printf("-");
    while(head)
    {
        printf("%d",head->data);
        head=head->next;
    }
}
