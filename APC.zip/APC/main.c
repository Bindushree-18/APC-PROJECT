#include "header.h"

int main(int argc,char* argv[])
{
    d_list* list1=NULL;
    d_list* list2=NULL;
    d_list* tail1=NULL;
    d_list* tail2=NULL;
    char n_flag=0;
    if(argc>5 || argc<4)
    {
        printf("\n Please give correct input!!\nUsage: <file_name> <operand> <+ or - or * or /> <operand2>");
       return 0;
    }
    find_largest(&n_flag,argv,&list1,&tail1,&list2,&tail2);
   
    call_fun(argv,&list1,&list2,&tail1,&tail2,n_flag);
    return 0;
}
