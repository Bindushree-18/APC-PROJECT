#include "header.h"
void insert_before(d_list** r_head,d_list** r_tail,int data)
{
    d_list* new=malloc(sizeof(d_list));
        new->data=data;
        new->prev=NULL;
    if(*r_head==NULL)
    {
        new->next=NULL;
        *r_head=new;
        *r_tail=new;
    }
    else
    {
        new->next=*r_head;
        (*r_head)->prev=new;
        *r_head=new;
    }
}


d_list* addition(d_list* t1,d_list* t2)
{
    d_list* tail1=t1;
    d_list* tail2=t2;
    d_list* r_head=NULL;
    d_list* r_tail=NULL;
    int carry=0;
    int r_data;
    d_list* new;
    while(tail1 || tail2)
    {
        if(tail2)
        {
            r_data=tail1->data+carry+tail2->data;
            tail1=tail1->prev;
            tail2=tail2->prev;
            if(r_data>=10)
            {
                r_data=r_data%10;
                carry=1;
            }
            else
                carry=0;
            insert_before(&r_head,&r_tail,r_data);
        }
        else
        {
            r_data=tail1->data+carry;
            tail1=tail1->prev;
            if(r_data>=10)
            {
                r_data=r_data%10;
                carry=1;
            }
            else
                carry=0;
            insert_before(&r_head,&r_tail,r_data);
        }
    }
    if(carry)
    {
        insert_before(&r_head,&r_tail,carry);
    }
    return r_head;
}
