#include "header.h"
int division(d_list* list1,d_list* tail1,d_list* list2,d_list* tail2)
{
    d_list* t1=tail1;
    d_list* t2=tail2;
    d_list* h1=list1;
    d_list* h2=list2;
    int count=0;
    d_list* r_head=NULL;
    int size_check=0;
    while(1)
    {
        size_check=find_size(h1,h2);
        if(size_check==1)
        {
            count++;
            r_head=subtraction(t1,t2);
            while(t1->prev)
            {
                t1=t1->prev;
                free(t1->next);
            }
            free(t1);
            while(r_head)
            {   
                if(r_head->data== 0)
                {
                    r_head=r_head->next;
                    if(r_head==NULL)
                        return count;
                    free(r_head->prev);
                    r_head->prev=NULL;
                }
                else
                    break;
            }
            t1=r_head;
            while(t1->next)
                t1=t1->next;
            h1=r_head;
        }
        else
            return count;
    }
}
int find_size(d_list* head1,d_list* head2)
{
    d_list* t1=head1;
    d_list* t2=head2;
    int len1=0;
    int len2=0;
    while(t1)
    {
        len1++;
        t1=t1->next;
    }
    while(t2)
    {
        len2++;
        t2=t2->next;
    }
    if(len1<len2)
        return 0;
    t1=head1;
    t2=head2;
    if(len1 == len2)
    {
        while(t1||t2)
        {
            if(t1->data < t2->data)
                return 0;
            t1=t1->next;
            t2=t2->next;
        }
        return 1;
    }
    else
        return 1;

}

