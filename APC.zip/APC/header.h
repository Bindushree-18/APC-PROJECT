#ifndef HEADER_H
#define HEADER_H
#include<stdlib.h>
#include<stdio.h>
#include<string.h>
#include<stdlib.h>
#include<stdio_ext.h>
enum e1
{
    SUCCESS,
    FAILURE,
    LIST_EMPTY
};
typedef struct node
{
    struct node* prev;
    int data;
    struct node* next;
}d_list;

void find_largest(char *n_flag,char* argv[],d_list** list1,d_list** tail1, d_list** list2,d_list** tail2);
void create_list(char* str1,char* str2,d_list** list1,d_list** tail1,d_list** list2,d_list** tail2);
d_list* addition(d_list* t1,d_list* t2);
void insert_before(d_list** r_head,d_list** r_tail,int data);
d_list* subtraction(d_list* t1,d_list* t2);
void call_fun(char* argv[],d_list** list1,d_list** list2,d_list** tail1,d_list** tail2,int n_flag);
void print_res(d_list* r_head,int n_flag);
d_list* multi(d_list* tail1,d_list* tail2);
int division(d_list* list1,d_list* tail1,d_list* list2,d_list* tail2);
int find_size(d_list* head1,d_list* head2);
#endif
