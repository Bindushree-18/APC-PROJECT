#include "header.h"
void find_largest(char *n_flag,char* argv[],d_list** list1,d_list** tail1, d_list** list2,d_list** tail2)
{
    int len1,len2;
    int i=0;
    int j=0;
    char* str1=argv[1];
    char* str2=argv[3];
    len1 = strlen(str1);
    len2 = strlen(str2);
    int weight1=0,weight2=0;
    if(str1[0]=='+' || str1[0]=='-')
        len1--;
    if(str2[0]=='+' || str2[0]=='-')
        len2--;
    if(len1 == len2)
    {
        if(str1[0]=='-' || str1[0]=='+')
            i++;
        if(str2[0]=='-' || str2[0]=='+')
            j++;
        while(str2[j]&&str1[i])
        {
            if(str2[j]>str1[i])
            {
                *n_flag=1;
                break;
            }
            i++;
            j++;
        }

    }
    if(len2>len1)
    {
        *n_flag=1;
    }

    if(*n_flag==1)
    {
        str1=argv[3];
        str2=argv[1];
    }
if(len1>1&& len2>1)
    if(str1[1]<48 || str1[1]>57 || str2[1]>57 || str2[1]<48)
{
    printf("invalid input");
    return;
}
    create_list(str1,str2,list1,tail1,list2,tail2);
}

void create_list(char* str1,char* str2,d_list** list1,d_list** tail1,d_list** list2,d_list** tail2)
{
    d_list* new;
    int i= strlen(str1)-1;
    while(i>=0)
    {
        if(str1[i]=='-' || str1[i]=='+')
            break;
        new=malloc(sizeof(d_list));
        new->data=str1[i]-48;
        new->prev=NULL;
        if(*list1==NULL)
        {
            new->next=NULL;
            *list1=new;
            *tail1=new;
        }
        else
        {
            new->next=*list1;
            (*list1)->prev=new;
            *list1=new;
        }
        i--;
    }
    i=strlen(str2)-1;
     while(i>=0)
    {
        if(str2[i]=='-' || str2[i]=='+')
            break;
        new=malloc(sizeof(d_list));
        new->data=str2[i]-48;
        new->prev=NULL;
        if(*list2==NULL)
        {
            new->next=NULL;
            *list2=new;
            *tail2=new;
        }
        else
        {
            new->next=*list2;
            (*list2)->prev=new;
            *list2=new;
        }
        i--;
    }
}


