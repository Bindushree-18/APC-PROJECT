#include "header.h"
d_list* subtraction(d_list* t1,d_list* t2)
{
    d_list* tail1=t1;
    d_list* tail2=t2;
    d_list* r_head=NULL;
    d_list* r_tail=NULL;
    int borrow=0;
    int r_data;
    d_list* new;
    while(tail1 || tail2)
    {
        if(tail2)
        {   r_data=tail1->data-borrow;
            if(r_data < tail2->data)
            {
                r_data=r_data+10;
                borrow=1;
            }
            else
                borrow=0;
            r_data=r_data - tail2->data;
            tail1=tail1->prev;
            tail2=tail2->prev;
        }
        else
        {
            r_data=tail1->data-borrow;
            if(r_data<0)
            {
                r_data=r_data+10;
                borrow=1;
                tail1=tail1->prev;
            }
            else{
                tail1=tail1->prev;
                borrow=0;
            }
        }
        insert_before(&r_head,&r_tail,r_data);
        
    }
    return r_head;
}
