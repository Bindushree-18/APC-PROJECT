#include"header.h"
d_list* multi(d_list* tail1,d_list* tail2)
{
    d_list* m_result=NULL;
    d_list* new;
    new=malloc(sizeof(d_list));
    new->next=NULL;
    new->prev=NULL;
    new->data=0;
    d_list* m_head=new;
    d_list* m_tail=new;
    d_list* t1=tail1;
    d_list* t2=tail2;
    d_list* r_head=NULL;
    d_list* r_tail=NULL;
    d_list* head=NULL;
    d_list* tail=NULL;
    d_list* h_temp;
    int i=0;
    int sum=0;
    int carry=0;
    while(t2)
    {
        for(int j=0;j<i;j++)
        {
            insert_before(&r_head,&r_tail,0);
        }
        i++;
        t1=tail1;
        while(t1)
        {
            sum=(t1->data)*(t2->data)+carry;
            if(sum>=10)
            {
                insert_before(&r_head,&r_tail,sum%10);
                carry=sum/10;
            }
            else
            {
                carry=0;
                insert_before(&r_head,&r_tail,sum);
            }
            t1=t1->prev;
        }
        if(carry)
        {
            insert_before(&r_head,&r_tail,carry);
            carry=0;
        }
        head=addition(r_tail,m_tail);

        //clear main_head
        while(m_head->next)
        {
            m_head=m_head->next;
            free(m_head->prev);
        }
        free(m_head);
        m_head=NULL;
        m_tail=NULL;
        //head to m_head
        h_temp=head;
        while(h_temp->next)
            h_temp=h_temp->next;
        tail=h_temp;

        while(tail)
        {
            insert_before(&m_head,&m_tail,tail->data);
            tail=tail->prev;
        }
        //free the head
        while(head->next)
        {
            head=head->next;
            free(head->prev);
        }
        free(head);
        while(r_head->next)
        {
            r_head=r_head->next;
            free(r_head->prev);
        }
        //free the r_head and r_tail
        free(r_head);
        r_head=NULL;
        r_tail=NULL;
        head=NULL;
        tail=NULL;
        t2=t2->prev;
    }
    return m_head;
}
